<header class="header-fixed">

    <div class="header-limiter">

        <h1><a href="{{url('/')}}"><div class="titulou">C o n t r o l <span>H o t e l</span></div></a></h1>



        <nav>
            <a href="{{url('/')}}">Home</a>
            <a href="{{url('sobre')}}">Sobre</a>
            <a href="{{url('politica')}}">Política de Privacidade</a>
            <a href="{{url('contato')}}">Fale conosco</a>
            <a href="{{url('login')}}"><button class="login100">Login</button></a>
        </nav>

    </div>

</header>