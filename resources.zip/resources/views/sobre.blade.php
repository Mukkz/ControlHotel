@extends('padrao.head')

@section('titulo', 'Sobre')

<body>

    @include('padrao.header')

	<div class="container-generico" style="background-image: url('{{'../assets/images/bg-02.jpg'}}');">
		<div>
            <h1 style="color: white ; font-family: Ubuntu-Bold; font-size: 50px">Sobre</h1>
            <hr>
			<p style="color: white ; font-family: Ubuntu-Regular; font-size: 20px">Lorem ipsum dolor sit amet, has philosophia deterruisset id. Sit quodsi omnesque te, ut nostro vocibus intellegebat per. Ei eum dolorem philosophia, his laudem doming no. Sea ad enim fabellas volutpat. Ea cum inermis volutpat. Mel ea iuvaret commune suavitate.

                Cibo consulatu ne has, has et postulant reformidans. Et qui oporteat perfecto, eos et appareat assentior, stet movet accommodare an usu. Ne senserit gubergren scriptorem has, mollis nonumes qui no. No eius percipitur sea, pri impetus gubergren sententiae ne. No porro omnes interpretaris quo, no nam mundi decore mnesarchum.

                Suas porro omnes ne mei. Ius te putent nostrud convenire, ei nibh quas luptatum mei. Illud antiopam urbanitas at eos, an ius saperet ocurreret, vel at percipit deserunt. Ridens labitur dissentiet cu qui, te feugait urbanitas vel. No quaeque molestie qui. Eum audiam alterum an. Has eu dolorem explicari, vim admodum maiorum probatus ex, ut vel vide regione.

                Sed at justo numquam appellantur, mazim apeirian vix cu. No partiendo scriptorem complectitur sed, vis exerci ceteros accumsan ea, ad nam hinc impedit. Phaedrum periculis cu qui, ne nam altera eleifend, te vel semper dissentiet. Duis definitionem ad quo. Veri zril no sed.

                Appetere percipitur at qui, dico oratio mucius eu his, audire accusata ut vim. Ne mea fabulas patrioque, ius ne sale platonem suavitate. Ius in impedit suscipit tincidunt, vim ne regione senserit signiferumque. Quas omnes comprehensam et mea, deleniti recteque ne vix. Eam no fugit oratio.</p>
		</div>
	</div>

    @include('padrao.footer')

</body>
